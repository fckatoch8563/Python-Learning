from collections import Counter


def find_most_repetitive(L1):
    """Find the most repetitive element in a list"""
    if not L1:
        return None

    # Count occurrences of each element
    count = Counter(L1)

    # Get the element with maximum count
    most_repetitive = count.most_common(1)[0][0]
    max_count = count.most_common(1)[0][1]

    return most_repetitive, max_count


# Test with the given list
L1 = [1, 2, 2, 3, 2, 3, 4, 5]

element, frequency = find_most_repetitive(L1)

print(f"List: {L1}")
print(f"\nElement frequencies:")
for elem in sorted(set(L1)):
    count = L1.count(elem)
    print(f"  {elem} appears {count} time(s)")

print(f"\nMost repetitive element: {element}")
print(f"Frequency: {frequency} times")
