"""Simplified YouTube Downloader - Downloads video or audio using yt-dlp."""

import os
import shutil
import subprocess

from yt_dlp import YoutubeDL


def download_youtube(
    url: str, format_selector: str, output_template: str
) -> str | None:
    """Download using yt-dlp with the specified format."""
    ydl_opts = {
        "format": format_selector,
        "outtmpl": output_template,
        "noplaylist": True,
        "quiet": False,
    }

    # Only enable merge if format selector requests multiple formats
    if "+" in format_selector:
        ydl_opts["merge_output_format"] = "mp4"

    try:
        with YoutubeDL(ydl_opts) as ydl:
            result = ydl.extract_info(url, download=True)
            if result:
                return ydl.prepare_filename(result)
        return None
    except Exception as e:
        print(f"Download error: {e}")
        return None


def convert_to_mp3(file_path: str) -> bool:
    """Convert audio file to MP3 using ffmpeg."""
    ffmpeg_path = shutil.which("ffmpeg")
    if not ffmpeg_path:
        print("ffmpeg not found. Install: winget install FFmpeg")
        return False

    mp3_path = os.path.splitext(file_path)[0] + ".mp3"
    try:
        subprocess.run(
            [ffmpeg_path, "-y", "-i", file_path, "-q:a", "0", mp3_path],
            check=True,
            capture_output=True,
        )
        print(f"MP3 saved: {mp3_path}")

        # Optionally remove original file
        remove = input("Remove original file? (y/N): ").strip().lower()
        if remove == "y":
            os.remove(file_path)
            print(f"Removed: {file_path}")
        return True
    except Exception as e:
        print(f"MP3 conversion failed: {e}")
        return False


def main():
    """Main download flow."""
    print("=" * 60)
    print("YouTube Downloader")
    print("=" * 60)

    # Get URL
    url = input("\nEnter YouTube URL: ").strip()
    if not url:
        print("Error: URL is required")
        return

    # Get download type
    download_type = (
        input("Download type (video/audio, default=video): ").strip().lower()
    )
    if not download_type:
        download_type = "video"

    if download_type not in {"video", "audio"}:
        print("Error: Invalid download type. Use 'video' or 'audio'")
        return

    # Get filename
    filename = input("Filename (optional, press Enter for video title): ").strip()

    # Setup output directory and template
    output_dir = "downloads"
    os.makedirs(output_dir, exist_ok=True)

    if filename:
        output_template = os.path.join(output_dir, f"{filename}.%(ext)s")
    else:
        output_template = os.path.join(output_dir, "%(title)s.%(ext)s")

    # Download
    print(f"\n{'=' * 60}")
    print(f"Downloading {download_type}...")
    print(f"{'=' * 60}")

    # Use 'best' format which prefers combined video+audio and avoids merge issues
    format_selector = "best"

    file_path = download_youtube(url, format_selector, output_template)

    if not file_path or not os.path.exists(file_path):
        print("\nDownload failed!")
        return

    print(f"\n✓ Downloaded: {file_path}")
    print(f"  Location: {os.path.abspath(file_path)}")

    # MP3 conversion for audio
    if download_type == "audio":
        convert = input("\nConvert to MP3? (y/N): ").strip().lower()
        if convert == "y":
            convert_to_mp3(file_path)

    print("\n✓ Done!")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nCancelled by user")
    except Exception as e:
        print(f"\nError: {e}")
