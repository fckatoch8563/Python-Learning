import json
import os
import shutil
import subprocess
import time
import urllib.request

from yt_dlp import YoutubeDL

DEFAULT_SPEED_TEST_URL = "http://ipv4.download.thinkbroadband.com/10MB.zip"
MAX_TEST_BYTES = 5 * 1024 * 1024
SPEED_CACHE_PATH = os.path.join("downloads", ".speed_cache.json")


def measure_download_speed(test_url: str, max_bytes: int) -> float:
    start = time.perf_counter()
    downloaded = 0
    with urllib.request.urlopen(test_url, timeout=20) as response:
        while downloaded < max_bytes:
            chunk = response.read(min(256 * 1024, max_bytes - downloaded))
            if not chunk:
                break
            downloaded += len(chunk)
    elapsed = time.perf_counter() - start
    if elapsed <= 0 or downloaded <= 0:
        raise RuntimeError("Speed test failed.")
    return (downloaded * 8) / (elapsed * 1_000_000)


def load_cached_speed() -> float | None:
    os.makedirs(os.path.dirname(SPEED_CACHE_PATH), exist_ok=True)
    if not os.path.exists(SPEED_CACHE_PATH):
        return None
    try:
        with open(SPEED_CACHE_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        speed = float(data.get("speed_mbps"))
        if speed <= 0:
            return None
        return speed
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def save_cached_speed(speed_mbps: float) -> None:
    os.makedirs(os.path.dirname(SPEED_CACHE_PATH), exist_ok=True)
    try:
        with open(SPEED_CACHE_PATH, "w", encoding="utf-8") as handle:
            json.dump({"speed_mbps": speed_mbps}, handle)
    except OSError:
        pass


def resolve_ffmpeg_path() -> str | None:
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path:
        return ffmpeg_path
    manual_path = input(
        "ffmpeg not found. Enter full path to ffmpeg.exe (Enter to skip): "
    ).strip()
    if not manual_path:
        return None
    if os.path.isfile(manual_path) and manual_path.lower().endswith("ffmpeg.exe"):
        return manual_path
    print("Invalid ffmpeg path; skipping MP3 conversion.")
    return None


url = input("Enter the YouTube video URL: ")

try:
    download_type = (
        input("Download type (video/audio, Enter for video): ").strip().lower()
    )
    if download_type and download_type not in {"video", "audio"}:
        raise RuntimeError("Invalid download type. Use 'video' or 'audio'.")
    output_dir = "downloads"
    os.makedirs(output_dir, exist_ok=True)

    with YoutubeDL({"noplaylist": True, "quiet": True}) as ydl:
        info = ydl.extract_info(url, download=False)

    if download_type == "audio":
        formats = [
            fmt for fmt in info.get("formats", []) if fmt.get("vcodec") == "none"
        ]
        if not formats:
            raise RuntimeError("No audio-only streams found for this video.")

        formats.sort(
            key=lambda fmt: fmt.get("abr") or fmt.get("tbr") or 0, reverse=True
        )
        print("Available audio options:")
        for index, fmt in enumerate(formats, start=1):
            size_bytes = fmt.get("filesize") or fmt.get("filesize_approx") or 0
            size_mb = size_bytes / (1024 * 1024)
            label = fmt.get("abr") or fmt.get("tbr")
            label_text = f"{label} kbps" if label else "unknown bitrate"
            ext = fmt.get("ext") or "unknown"
            print(f"{index}. {label_text} - {ext} - {size_mb:.1f} MB")

        choice = input("Choose an audio option by number (Enter for best): ").strip()
    else:
        formats = [
            fmt
            for fmt in info.get("formats", [])
            if fmt.get("vcodec") != "none"
            and fmt.get("acodec") != "none"
            and fmt.get("ext") == "mp4"
        ]
        if not formats:
            raise RuntimeError("No compatible MP4 stream found for this video.")

        formats.sort(key=lambda fmt: fmt.get("height") or 0, reverse=True)
        print("Available resolutions:")
        for index, fmt in enumerate(formats, start=1):
            size_bytes = fmt.get("filesize") or fmt.get("filesize_approx") or 0
            size_mb = size_bytes / (1024 * 1024)
            height = fmt.get("height")
            label = f"{height}p" if height else "unknown"
            print(f"{index}. {label} - {size_mb:.1f} MB")

        choice = input("Choose a resolution by number (Enter for highest): ").strip()

    if choice:
        try:
            selected_index = int(choice) - 1
            selected_format = formats[selected_index]
        except (ValueError, IndexError) as exc:
            raise RuntimeError("Invalid resolution choice.") from exc
    else:
        selected_format = formats[0]

    size_bytes = (
        selected_format.get("filesize") or selected_format.get("filesize_approx") or 0
    )
    if size_bytes:
        auto_speed = (
            input("Auto-detect download speed for time estimate? (y/N): ")
            .strip()
            .lower()
        )
        speed_mbps = None
        if auto_speed == "y":
            cached_speed = load_cached_speed()
            if cached_speed is not None:
                use_cached = (
                    input(f"Use cached speed {cached_speed:.1f} Mbps? (Y/n): ")
                    .strip()
                    .lower()
                )
                if use_cached in {"", "y", "yes"}:
                    speed_mbps = cached_speed
            test_url = input(f"Speed test URL (Enter for default): ").strip()
            if not test_url:
                test_url = DEFAULT_SPEED_TEST_URL
            try:
                if speed_mbps is None:
                    speed_mbps = measure_download_speed(test_url, MAX_TEST_BYTES)
                    save_cached_speed(speed_mbps)
                    print(f"Estimated speed: {speed_mbps:.1f} Mbps")
            except Exception as exc:
                print(f"Speed test failed: {exc}")
        if speed_mbps is None:
            speed_input = input(
                "Enter your download speed in Mbps for time estimate (Enter to skip): "
            ).strip()
            if speed_input:
                try:
                    speed_mbps = float(speed_input)
                    if speed_mbps <= 0:
                        raise ValueError
                except ValueError:
                    print("Invalid speed input. Skipping time estimate.")
                    speed_mbps = None
        if speed_mbps:
            seconds = (size_bytes * 8) / (speed_mbps * 1_000_000)
            minutes = seconds / 60
            if minutes >= 1:
                print(f"Estimated download time: {minutes:.1f} minutes")
            else:
                print(f"Estimated download time: {seconds:.0f} seconds")
    else:
        print("File size unknown; skipping time estimate.")

    filename = input(
        "Enter filename without extension (Enter to keep default): "
    ).strip()
    if filename:
        outtmpl = os.path.join(output_dir, f"{filename}.%(ext)s")
    else:
        outtmpl = os.path.join(output_dir, "%(title)s.%(ext)s")

    ydl_opts = {
        "format": selected_format.get("format_id"),
        "outtmpl": outtmpl,
        "noplaylist": True,
    }
    with YoutubeDL(ydl_opts) as ydl:
        result = ydl.extract_info(url, download=True)
        file_path = None
        requested = result.get("requested_downloads")
        if requested:
            file_path = requested[0].get("filepath")
        if not file_path:
            file_path = ydl.prepare_filename(result)

    if download_type == "audio":
        convert = input("Convert to MP3 with ffmpeg? (y/N): ").strip().lower()
        if convert == "y":
            ffmpeg_path = resolve_ffmpeg_path()
            if ffmpeg_path:
                mp3_path = os.path.splitext(file_path)[0] + ".mp3"
                try:
                    subprocess.run(
                        [ffmpeg_path, "-y", "-i", file_path, "-q:a", "0", mp3_path],
                        check=True,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    print(f"MP3 saved to: {mp3_path} (VBR quality: ~245 kbps)")
                except Exception as exc:
                    print(f"MP3 conversion failed: {exc}")
    print("Download completed!")
except Exception as exc:
    print(f"Download failed: {exc}")


# cd "C:\Users\fckat\Desktop\Learn Python" streamlit run streamlit_app.py
